#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 29 21:56:52 2018

@author: ivan
"""

from . import somePython
